package com.shopify.app.entity;

public enum Role {
	BUYER ,
	SELLER
}
